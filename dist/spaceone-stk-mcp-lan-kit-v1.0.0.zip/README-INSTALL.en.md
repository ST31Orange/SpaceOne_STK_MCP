# SpaceOne_STK_MCP — LAN Offline Install Guide (v1.0.0)

Installs the SpaceOne_STK_MCP plugin on an **intranet (offline)** Windows machine. The plugin
controls a **local** STK 11/12 via Python + COM and provides 42 `stk_*` function-calling tools
to DSH.

## 1. Prerequisites (per machine)

| Item | Requirement |
|---|---|
| Windows | Windows 10/11 x64 |
| STK | STK 11 or STK 12 **installed and licensed locally** (COM automation, no remoting) |
| Python | Python 3.12 x64 (wheels are built for 3.12 x64; other versions need online pip) |
| DSH | DeepSeek Harness desktop installed and signed in |
| Network | This kit is **fully offline** |

## 2. Copy and extract

Copy `spaceone-stk-mcp-lan-kit-v1.0.0.zip` to the target machine and extract to a path
**without spaces or Chinese characters**, e.g. `C:\DSH-STK`.

```
C:\DSH-STK\
├─ python\wheels\                        # spaceone-stk-mcp + all dependency wheels (37, offline)
├─ plugin\spaceone-stk-plugin-1.0.0.tgz  # plugin package
├─ install.ps1
├─ verify.ps1
└─ README-INSTALL.md
```

## 3. One-click install

```powershell
cd C:\DSH-STK
powershell -ExecutionPolicy Bypass -File .\install.ps1 -InstallRoot C:\DSH-STK
```

The script: creates a venv, installs wheels offline, runs `spaceone-stk-mcp doctor`, installs
the plugin tarball into the `desktop` profile, and writes `pythonPath` into the profile patch.

Optional:

```powershell
.\install.ps1 -InstallRoot C:\DSH-STK -PythonExe "C:\Python312\python.exe"
.\install.ps1 -InstallRoot C:\DSH-STK -DshCli "D:\DSH\resources\runtime\cli\bin\dsh.cmd"
.\install.ps1 -InstallRoot C:\DSH-STK -SkipDoctor
```

## 4. Verify

```powershell
powershell -ExecutionPolicy Bypass -File .\verify.ps1 -InstallRoot C:\DSH-STK
```

`VERIFY PASS` means: Python package imports, catalog has 77 operations, kernel `/health`
returns `tool_count=77` (no STK needed), and the plugin is in the profile with a pythonPath.

## 5. Restart DSH and try

1. Fully quit and restart DeepSeek Harness.
2. Open a new session and ask: `列出所有 stk_* 工具` → expect **42 stk_* tools**.
3. The first tool call auto-starts the Python kernel on `127.0.0.1:8080`.

## 6. Manual install

```powershell
py -3.12 -m venv C:\DSH-STK\venv
C:\DSH-STK\venv\Scripts\python.exe -m pip install --no-index --find-links C:\DSH-STK\python\wheels spaceone-stk-mcp==1.0.0
"%LOCALAPPDATA%\Programs\DeepSeek Harness\resources\runtime\cli\bin\dsh.cmd" plugin --profile desktop add "file:C:\DSH-STK\plugin\spaceone-stk-plugin-1.0.0.tgz"
```

Append to `C:\Users\<user>\.dsh\profiles\desktop\cordis.patch.yml` (if the file only contains
`[]`, replace it with the block below):

```yaml
- id: spaceone-stk-plugin
  name: spaceone-stk-plugin
  config:
    baseUrl: http://127.0.0.1:8080
    autoStart: true
    pythonPath: C:\DSH-STK\venv\Scripts\python.exe
    timeoutMs: 180000
```

Then restart DSH.

## 7. Upgrade

```powershell
dsh plugin --profile desktop remove spaceone-stk-plugin
dsh plugin --profile desktop add "file:C:\DSH-STK\plugin\spaceone-stk-plugin-1.0.0.tgz"
```

Tarball install **copies** the plugin into the profile; the source folder is not required
after install.

## 8. LAN notes

- Every machine needs its own STK, its own venv, and its own plugin install.
- The Python kernel listens on `127.0.0.1:8080` (local only); no LAN ports need to be opened.

## 9. Troubleshooting

| Symptom | Fix |
|---|---|
| No `stk_*` tools in chat | Restart DSH; check profile patch; confirm profile is `desktop` |
| `STK_KERNEL_START_TIMEOUT` | Wrong `pythonPath` or missing venv; run `venv\Scripts\spaceone-stk-mcp.exe serve-http --port 8080` manually |
| `STK_NOT_CONNECTED` | STK missing/unlicensed; run `venv\Scripts\spaceone-stk-mcp.exe doctor` |
| Port 8080 busy | Change `baseUrl` and kernel port, or stop the conflicting app |
| `UNSAFE_SAVE_DIRECTORY` | Save dir contains unrelated files; use a new empty dir (e.g. `C:\STK\mission\mission.sc`) |
| `SAVE_TOO_LARGE` | Scenario dir > 2 GB; inspect for unrelated large files |

## 10. Defaults (safe by design)

- **Headed by default**: `STK_MCP_VISIBLE=true`, `STK_MCP_USER_CONTROL=true`.
- **Scenario stays open**: tasks do not close the scenario or quit STK.
- **Save requires confirmation**: `scenario_save` needs `confirm_save=true`; ASCII-only paths;
  the save directory must be new/empty or dedicated to this scenario; 2 GB size limit.

## 11. Dev link (optional)

```powershell
dsh plugin --profile desktop add "link:D:\DSH_AI\DSH_STK_MCP\spaceone-stk-plugin"
```
