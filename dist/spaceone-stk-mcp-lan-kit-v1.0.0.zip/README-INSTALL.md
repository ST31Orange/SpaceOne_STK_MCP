# SpaceOne_STK_MCP — 局域网离线安装指南（v1.0.0）

本包用于在**内网（无外网）**的 Windows 电脑上安装 SpaceOne_STK_MCP。插件通过 Python + COM 控制
本机 STK 11/12，为 DSH 提供 42 个 `stk_*` Function Calling 工具（场景/轨道/访问/覆盖/报告/设备/
平台航路/面目标/Walker/Astrogator 等）。

## 1. 前置条件（每台目标机）

| 条件 | 说明 |
|---|---|
| Windows | Windows 10/11 x64 |
| STK | **必须在本机安装并授权** STK 11 或 STK 12（COM 自动化，不跨机器） |
| Python | Python 3.12 x64（本包 wheel 按 3.12 x64 打包；其他版本请联网用 pip 安装） |
| DSH | DeepSeek Harness 桌面版已安装并登录 |
| 网络 | 本包**完全离线**，不需要外网 |

> STK 无法随包分发：每台电脑必须各自安装 STK 并激活许可证。

## 2. 拷贝并解压

把 `spaceone-stk-mcp-lan-kit-v1.0.0.zip` 通过共享文件夹 / U 盘拷到目标机，解压到**无空格、无中文**
的路径，例如：

```text
C:\DSH-STK
```

解压后结构：

```text
C:\DSH-STK\
├─ python\wheels\                        # spaceone-stk-mcp + 全部依赖 wheel（37 个，离线）
├─ plugin\spaceone-stk-plugin-1.0.0.tgz  # 插件安装包
├─ install.ps1                           # 一键安装脚本
├─ verify.ps1                            # 校验脚本
└─ README-INSTALL.md
```

## 3. 一键安装（推荐）

打开 PowerShell（普通用户即可，无需管理员）：

```powershell
cd C:\DSH-STK
powershell -ExecutionPolicy Bypass -File .\install.ps1 -InstallRoot C:\DSH-STK
```

脚本自动完成：

1. 找到 Python 3.12（`py -3.12` 或 `python`）；
2. 在 `C:\DSH-STK\venv` 创建独立虚拟环境；
3. **离线**安装 `spaceone-stk-mcp 1.0.0` 及全部依赖；
4. 运行 `spaceone-stk-mcp doctor` 检查 Python/pywin32/STK ProgID；
5. 用 `dsh plugin` 把插件 tarball 装进 `desktop` profile；
6. 在 profile 的 `cordis.patch.yml` 写入 `pythonPath` 指向 venv 的 python。

可选参数：

```powershell
# 指定 Python 可执行文件
.\install.ps1 -InstallRoot C:\DSH-STK -PythonExe "C:\Python312\python.exe"
# 指定 DSH CLI 路径（DSH 没装在默认位置时）
.\install.ps1 -InstallRoot C:\DSH-STK -DshCli "D:\DSH\resources\runtime\cli\bin\dsh.cmd"
# 跳过 doctor（STK 还没装时）
.\install.ps1 -InstallRoot C:\DSH-STK -SkipDoctor
```

## 4. 校验

```powershell
cd C:\DSH-STK
powershell -ExecutionPolicy Bypass -File .\verify.ps1 -InstallRoot C:\DSH-STK
```

输出 `VERIFY PASS` 表示：

- `spaceone_stk_mcp` 可导入，目录 77 个操作；
- 内核 `/health` 返回 `tool_count=77`（不需要 STK）；
- 插件已写进 `desktop` profile 并带 pythonPath 配置。

## 5. 重启 DSH 并试用

1. **完全退出并重启** DeepSeek Harness（不是刷新页面）；
2. 新开会话，输入：

```text
列出所有 stk_* 工具
```

应看到 **42 个 `stk_*` 工具**。第一次调用会自动启动 Python 内核
（`python -m spaceone_stk_mcp.cli serve-http --port 8080`）。

再试一次真实调用：

```text
用 stk_status 检查 STK 连接；然后建一个测试场景，用 stk_facility_create 建北京地面站。
```

## 6. 手动安装（不用脚本）

```powershell
# 1) venv
py -3.12 -m venv C:\DSH-STK\venv

# 2) 离线装 Python 包
C:\DSH-STK\venv\Scripts\python.exe -m pip install --no-index --find-links C:\DSH-STK\python\wheels spaceone-stk-mcp==1.0.0

# 3) 装插件（DSH CLI 路径按实际安装位置）
"%LOCALAPPDATA%\Programs\DeepSeek Harness\resources\runtime\cli\bin\dsh.cmd" plugin --profile desktop add "file:C:\DSH-STK\plugin\spaceone-stk-plugin-1.0.0.tgz"
```

然后编辑 `C:\Users\<你的用户名>\.dsh\profiles\desktop\cordis.patch.yml`。若文件内容只有 `[]`，**直接替换**
为下面的内容；否则追加到末尾：

```yaml
- id: spaceone-stk-plugin
  name: spaceone-stk-plugin
  config:
    baseUrl: http://127.0.0.1:8080
    autoStart: true
    pythonPath: C:\DSH-STK\venv\Scripts\python.exe
    timeoutMs: 180000
```

重启 DSH。

## 7. 升级 / 重装

```powershell
# 先卸载旧插件
dsh plugin --profile desktop remove spaceone-stk-plugin
# 再装新 tarball（新版本包）
dsh plugin --profile desktop add "file:C:\DSH-STK\plugin\spaceone-stk-plugin-1.0.0.tgz"
```

> 从 tarball 安装会**复制**进 profile，不依赖源目录；源包删除后插件仍可用。
> Python 包升级：直接重新运行 install.ps1（pip 会覆盖同版本），或手动
> `venv\Scripts\pip install --no-index --find-links wheels spaceone-stk-mcp==新版本`。

## 8. 局域网多台机器

- 每台机器都要：装 STK + 本包 + 各自 venv + 各自 profile 插件；
- Python 内核监听 `127.0.0.1:8080`，是**单机本地**服务，不需要局域网端口开放；
- 插件与 Python 内核都在本机，不向局域网暴露数据。

## 9. 常见问题

| 现象 | 处理 |
|---|---|
| 工具列表里没有 `stk_*` | 重启 DSH；确认 `cordis.patch.yml` 有 spaceone-stk-plugin 条目；确认 profile 是 desktop |
| `STK_KERNEL_START_TIMEOUT` | `pythonPath` 写错或 venv 没建好；手动跑一遍 `venv\Scripts\spaceone-stk-mcp.exe serve-http --port 8080` |
| `STK_NOT_CONNECTED` | STK 未装/未授权；跑 `venv\Scripts\spaceone-stk-mcp.exe doctor` |
| 端口 8080 被占用 | 改 `baseUrl` 和内核端口（见文档），或先关掉占用程序 |
| `unknown tool "stk_xxx"` | 该操作不是直接工具；用 `stk_call` 调用，或用 `stk_list_tools` 查看 `direct_tool` |
| 保存报 `UNSAFE_SAVE_DIRECTORY` | 保存目录里有无关文件；换新空目录（如 `C:\STK\mission\mission.sc`） |
| 保存报 `SAVE_TOO_LARGE` | 场景目录超过 2 GB；检查无关大文件，不要盲目调大上限 |

## 10. 默认行为（安全设计）

- **默认有头**：`STK_MCP_VISIBLE=true`、`STK_MCP_USER_CONTROL=true`，STK 窗口可见可交互；
- **不自动关场景**：正常任务结束不关闭场景、不退出 STK，由用户自己关闭；
- **保存需确认**：`scenario_save` 必须 `confirm_save=true`，路径必须 ASCII（禁中文），
  保存目录必须是新空目录或该场景自己的目录；
- 场景目录上限 2 GB，超限报 `SAVE_TOO_LARGE`，避免把默认目录内容并进场景。

## 11. 本机开发版（可选）

如果目标机已装 `node` + `typescript`，也可以直接链接开发源码：

```powershell
dsh plugin --profile desktop add "link:D:\DSH_AI\DSH_STK_MCP\spaceone-stk-plugin"
```

`link` 方式会跟随源码变化，但要求源码目录长期存在；内网部署建议用上面的 tarball 方式。
