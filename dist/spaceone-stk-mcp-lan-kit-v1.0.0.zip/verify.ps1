# verify.ps1 - check a completed SpaceOne_STK_MCP LAN kit install
# Usage:
#   powershell -ExecutionPolicy Bypass -File .\verify.ps1 -InstallRoot C:\DSH-STK

param(
    [string]$InstallRoot = "C:\DSH-STK",
    [string]$Profile = "desktop"
)

$ErrorActionPreference = "Continue"
$fail = 0
$VenvPy = Join-Path $InstallRoot "venv\Scripts\python.exe"
$StkCli = Join-Path $InstallRoot "venv\Scripts\spaceone-stk-mcp.exe"

Write-Host "== 1. Python package =="
if (Test-Path $VenvPy) {
    & $VenvPy -c "import spaceone_stk_mcp, spaceone_stk_mcp.http_server, spaceone_stk_mcp.mcp_server; print('spaceone_stk_mcp import OK')"
    $cat = & $StkCli catalog 2>$null
    if ($cat -match '"tool_count": 77') { Write-Host "catalog: 77 tools OK" } else { Write-Host "catalog check FAILED"; $fail++ }
} else { Write-Host "venv missing: $VenvPy"; $fail++ }

Write-Host "== 2. HTTP kernel (no STK required) =="
$job = Start-Job -ScriptBlock { param($py,$port) & $py -m spaceone_stk_mcp.cli serve-http --port $port } -ArgumentList $VenvPy,18089
Start-Sleep -Seconds 8
try {
    $h = Invoke-RestMethod -Uri "http://127.0.0.1:18089/health" -TimeoutSec 5
    if ($h.tool_count -eq 77) { Write-Host "health OK tool_count=77" } else { Write-Host "health tool_count mismatch"; $fail++ }
} catch { Write-Host "health FAILED: $_"; $fail++ }
Stop-Job $job -ErrorAction SilentlyContinue
Remove-Job $job -Force -ErrorAction SilentlyContinue

Write-Host "== 3. Plugin in DSH profile =="
$ProfileDir = Join-Path $env:USERPROFILE ".dsh\profiles\$Profile"
$pkg = Join-Path $ProfileDir "package.json"
$lib = Join-Path $ProfileDir "node_modules\spaceone-stk-plugin\lib\index.js"
$patch = Join-Path $ProfileDir "cordis.patch.yml"
$inPkg = $false
if (Test-Path $pkg) { $inPkg = [bool](Select-String -Path $pkg -Pattern "spaceone-stk-plugin" -Quiet -ErrorAction SilentlyContinue) }
$inPatch = $false
if (Test-Path $patch) { $inPatch = [bool](Select-String -Path $patch -Pattern "spaceone-stk-plugin" -Quiet -ErrorAction SilentlyContinue) }
if ($inPkg) { Write-Host "profile package.json contains plugin OK" } else { Write-Host "plugin not in profile package.json"; $fail++ }
if (Test-Path $lib) { Write-Host "plugin lib present OK" } else { Write-Host "plugin lib missing"; $fail++ }
if ($inPatch) { Write-Host "patch entry present OK" } else { Write-Host "patch entry missing (pythonPath not set)"; $fail++ }

Write-Host ""
if ($fail -eq 0) { Write-Host "VERIFY PASS" } else { Write-Host "VERIFY FAIL ($fail checks failed)" }
exit $fail
