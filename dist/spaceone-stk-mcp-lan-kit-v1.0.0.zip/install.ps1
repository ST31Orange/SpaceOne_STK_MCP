# install.ps1 - offline install of the SpaceOne_STK_MCP LAN kit
#
# Requirements on the target machine:
#   - Windows 10/11 x64
#   - Python 3.12 x64 installed (py launcher or python on PATH)
#   - DeepSeek Harness (DSH) desktop installed and logged in
#   - STK 11 or STK 12 installed and licensed (local COM automation)
#
# Usage (PowerShell, no admin needed):
#   powershell -ExecutionPolicy Bypass -File .\install.ps1 -InstallRoot C:\DSH-STK
# Optional:
#   -PythonExe "C:\path\to\python.exe"
#   -DshCli "C:\path\to\dsh.cmd"
#   -SkipDoctor

param(
    [string]$InstallRoot = "C:\DSH-STK",
    [string]$Profile = "desktop",
    [string]$PythonExe = "",
    [string]$DshCli = "",
    [switch]$SkipDoctor
)

$ErrorActionPreference = "Stop"
$Kit = $PSScriptRoot

if (-not (Test-Path "$Kit\python\wheels")) { throw "wheels folder missing: $Kit\python\wheels" }
if (-not (Test-Path "$Kit\plugin\spaceone-stk-plugin-1.0.0.tgz")) { throw "plugin tarball missing: $Kit\plugin\spaceone-stk-plugin-1.0.0.tgz" }

# ---------------------------------------------------------------- Python
function Get-PythonExe {
    if ($PythonExe) { return $PythonExe }
    try {
        $p = & py -3.12 -c "import sys;print(sys.executable)" 2>$null
        if ($LASTEXITCODE -eq 0 -and $p) { return ($p.Trim()) }
    } catch {}
    try {
        $p = & python -c "import sys;print(sys.executable)" 2>$null
        if ($LASTEXITCODE -eq 0 -and $p) { return ($p.Trim()) }
    } catch {}
    throw "Python not found. Install Python 3.12 x64, or pass -PythonExe."
}
$Py = Get-PythonExe
Write-Host "Using Python: $Py"

# ---------------------------------------------------------------- venv
New-Item -ItemType Directory -Force -Path $InstallRoot | Out-Null
$VenvDir = Join-Path $InstallRoot "venv"
$VenvPy = Join-Path $VenvDir "Scripts\python.exe"
if (-not (Test-Path $VenvPy)) {
    Write-Host "Creating virtual environment at $VenvDir ..."
    & $Py -m venv $VenvDir
    if ($LASTEXITCODE -ne 0) { throw "venv creation failed" }
} else {
    Write-Host "venv already exists: $VenvDir"
}
if (-not (Test-Path $VenvPy)) { throw "venv python missing: $VenvPy" }

# ---------------------------------------------------------------- wheels
Write-Host "Installing spaceone-stk-mcp 1.0.0 and dependencies (fully offline)..."
& $VenvPy -m pip install --no-index --find-links "$Kit\python\wheels" "spaceone-stk-mcp==1.0.0"
if ($LASTEXITCODE -ne 0) { throw "pip install failed" }

# ---------------------------------------------------------------- doctor
if (-not $SkipDoctor) {
    $StkCli = Join-Path $InstallRoot "venv\Scripts\spaceone-stk-mcp.exe"
    Write-Host "Running spaceone-stk-mcp doctor (STK must be installed on this machine)..."
    & $StkCli doctor
}

# ---------------------------------------------------------------- DSH CLI
function Find-DshCli {
    if ($DshCli) { return $DshCli }
    $candidates = @(
        "$env:LOCALAPPDATA\Programs\DeepSeek Harness\resources\runtime\cli\bin\dsh.cmd",
        "$env:ProgramFiles\DeepSeek Harness\resources\runtime\cli\bin\dsh.cmd"
    )
    foreach ($c in $candidates) { if (Test-Path $c) { return $c } }
    $found = Get-ChildItem "$env:LOCALAPPDATA\Programs","$env:ProgramFiles" -Filter "dsh.cmd" -Recurse -ErrorAction SilentlyContinue | Select-Object -First 1
    if ($found) { return $found.FullName }
    return "dsh"
}
$Dsh = Find-DshCli
Write-Host "Using DSH CLI: $Dsh"

# ---------------------------------------------------------------- plugin
$ProfileDir = Join-Path $env:USERPROFILE ".dsh\profiles\$Profile"
$PkgJson = Join-Path $ProfileDir "package.json"
$PluginInstalled = $false
if (Test-Path $PkgJson) {
    $PluginInstalled = [bool](Select-String -Path $PkgJson -Pattern "spaceone-stk-plugin" -Quiet -ErrorAction SilentlyContinue)
}
if (-not $PluginInstalled) {
    Write-Host "Installing plugin into profile '$Profile' from tarball..."
    & $Dsh plugin --profile $Profile add "file:$Kit\plugin\spaceone-stk-plugin-1.0.0.tgz"
    if ($LASTEXITCODE -ne 0) { throw "dsh plugin add failed" }
} else {
    Write-Host "Plugin already installed in profile '$Profile'; skipping add (remove it first to upgrade)."
}

# ---------------------------------------------------------------- pythonPath config
$Patch = Join-Path $ProfileDir "cordis.patch.yml"
$PatchEntry = @"
- id: spaceone-stk-plugin
  name: spaceone-stk-plugin
  config:
    baseUrl: http://127.0.0.1:8080
    autoStart: true
    pythonPath: $VenvPy
    timeoutMs: 180000
"@
if (Test-Path $Patch) {
    $content = Get-Content $Patch -Raw -ErrorAction SilentlyContinue
    if ($content -match "spaceone-stk-plugin") {
        Write-Host "spaceone-stk-plugin already present in $Patch; pythonPath was NOT overwritten. Edit it manually if needed."
    } else {
        # Remove a bare empty-array line ("[]") if present, keep comments/other entries,
        # then append our entry. This keeps the YAML a valid top-level array.
        $lines = @(Get-Content $Patch -ErrorAction SilentlyContinue | Where-Object { $_.Trim() -ne '[]' })
        $lines += ""
        $lines += $PatchEntry
        Set-Content -Path $Patch -Value $lines
        Write-Host "Wrote pythonPath config into $Patch"
    }
} else {
    Write-Host "WARNING: profile patch not found at $Patch; configure pythonPath manually (see README-INSTALL.md)."
}

Write-Host ""
Write-Host "=================================================="
Write-Host "Install finished."
Write-Host "1) Fully quit and restart DeepSeek Harness."
Write-Host "2) Open a new chat session and ask: 列出所有 stk_* 工具"
Write-Host "3) You should see 42 stk_* tools. The first call auto-starts the Python kernel."
Write-Host "4) Run .\verify.ps1 -InstallRoot $InstallRoot to double-check."
Write-Host "=================================================="
